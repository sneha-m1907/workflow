import React, { useState } from 'react';
import { Send, Paperclip, Users, Search, MessageSquare, Hash } from 'lucide-react';

interface Message {
  id: number;
  content: string;
  sender: string;
  timestamp: string;
  type: 'private' | 'group';
  chatId: string;
}

interface Chat {
  id: string;
  name: string;
  type: 'private' | 'group';
  unreadCount: number;
  lastMessage?: string;
  participants?: string[];
}

const initialChats: Chat[] = [
  {
    id: 'private-1',
    name: 'Sarah K.',
    type: 'private',
    unreadCount: 2,
    lastMessage: 'Can you review the latest design?'
  },
  {
    id: 'private-2',
    name: 'Mike R.',
    type: 'private',
    unreadCount: 0,
    lastMessage: 'Thanks for the update!'
  },
  {
    id: 'group-1',
    name: 'Design Team',
    type: 'group',
    unreadCount: 5,
    lastMessage: 'New mockups are ready',
    participants: ['Sarah K.', 'Mike R.', 'Emma S.']
  },
  {
    id: 'group-2',
    name: 'Project Alpha',
    type: 'group',
    unreadCount: 0,
    lastMessage: 'Sprint planning tomorrow',
    participants: ['John D.', 'Chris P.', 'You']
  }
];

const initialMessages: Message[] = [
  {
    id: 1,
    content: 'Hey team, how\'s the progress on the new feature?',
    sender: 'Sarah K.',
    timestamp: '10:30 AM',
    type: 'group',
    chatId: 'group-1'
  },
  {
    id: 2,
    content: 'We\'re almost done with the implementation. Just need to run some final tests.',
    sender: 'You',
    timestamp: '10:32 AM',
    type: 'group',
    chatId: 'group-1'
  },
  {
    id: 3,
    content: 'Great work everyone! Let\'s review it tomorrow.',
    sender: 'Mike R.',
    timestamp: '10:35 AM',
    type: 'group',
    chatId: 'group-1'
  }
];

const ChatPanel = () => {
  const [activeChat, setActiveChat] = useState<Chat | null>(initialChats[0]);
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [newMessage, setNewMessage] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [showChatList, setShowChatList] = useState(true);

  const filteredChats = initialChats.filter(chat =>
    chat.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const chatMessages = messages.filter(msg => msg.chatId === activeChat?.id);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !activeChat) return;

    const message: Message = {
      id: messages.length + 1,
      content: newMessage,
      sender: 'You',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      type: activeChat.type,
      chatId: activeChat.id
    };

    setMessages([...messages, message]);
    setNewMessage('');
  };

  return (
    <div className="h-[600px] flex">
      {/* Chat List Sidebar */}
      <div className={`w-80 border-r ${showChatList ? 'block' : 'hidden'} md:block`}>
        <div className="p-4 border-b">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <input
              type="text"
              placeholder="Search chats..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>
        </div>
        <div className="overflow-y-auto h-[calc(100%-73px)]">
          {filteredChats.map((chat) => (
            <div
              key={chat.id}
              onClick={() => setActiveChat(chat)}
              className={`p-4 cursor-pointer hover:bg-gray-50 ${
                activeChat?.id === chat.id ? 'bg-indigo-50' : ''
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  {chat.type === 'private' ? (
                    <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center">
                      <MessageSquare className="h-5 w-5 text-gray-500" />
                    </div>
                  ) : (
                    <div className="h-10 w-10 rounded-full bg-indigo-100 flex items-center justify-center">
                      <Hash className="h-5 w-5 text-indigo-600" />
                    </div>
                  )}
                  <div>
                    <h3 className="font-medium text-gray-900">{chat.name}</h3>
                    <p className="text-sm text-gray-500 truncate">{chat.lastMessage}</p>
                  </div>
                </div>
                {chat.unreadCount > 0 && (
                  <span className="bg-indigo-600 text-white text-xs px-2 py-1 rounded-full">
                    {chat.unreadCount}
                  </span>
                )}
              </div>
              {chat.type === 'group' && (
                <div className="mt-2 flex items-center text-xs text-gray-500">
                  <Users className="h-3 w-3 mr-1" />
                  {chat.participants?.join(', ')}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 flex flex-col">
        {activeChat ? (
          <>
            <div className="p-4 border-b flex items-center justify-between">
              <div className="flex items-center space-x-3">
                {activeChat.type === 'private' ? (
                  <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center">
                    <MessageSquare className="h-5 w-5 text-gray-500" />
                  </div>
                ) : (
                  <div className="h-10 w-10 rounded-full bg-indigo-100 flex items-center justify-center">
                    <Hash className="h-5 w-5 text-indigo-600" />
                  </div>
                )}
                <div>
                  <h2 className="font-semibold text-gray-900">{activeChat.name}</h2>
                  {activeChat.type === 'group' && (
                    <p className="text-sm text-gray-500">
                      {activeChat.participants?.join(', ')}
                    </p>
                  )}
                </div>
              </div>
              <button
                onClick={() => setShowChatList(!showChatList)}
                className="md:hidden p-2 text-gray-500 hover:text-gray-600"
              >
                <Users className="h-5 w-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {chatMessages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex items-start space-x-2 ${
                    msg.sender === 'You' ? 'justify-end' : ''
                  }`}
                >
                  {msg.sender !== 'You' && (
                    <div className="h-8 w-8 rounded-full bg-gray-200"></div>
                  )}
                  <div
                    className={`rounded-lg p-3 max-w-md ${
                      msg.sender === 'You'
                        ? 'bg-indigo-100'
                        : 'bg-gray-100'
                    }`}
                  >
                    {msg.sender !== 'You' && (
                      <p className="text-xs font-medium text-gray-900 mb-1">
                        {msg.sender}
                      </p>
                    )}
                    <p className="text-sm text-gray-900">{msg.content}</p>
                    <span className="text-xs text-gray-500 mt-1 block">
                      {msg.timestamp}
                    </span>
                  </div>
                  {msg.sender === 'You' && (
                    <div className="h-8 w-8 rounded-full bg-indigo-200"></div>
                  )}
                </div>
              ))}
            </div>

            <form onSubmit={handleSend} className="border-t p-4">
              <div className="flex items-center space-x-2">
                <button
                  type="button"
                  className="p-2 text-gray-500 hover:text-gray-600"
                >
                  <Paperclip className="h-5 w-5" />
                </button>
                <input
                  type="text"
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  placeholder="Type your message..."
                  className="flex-1 rounded-lg border border-gray-300 px-4 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
                <button
                  type="submit"
                  className="bg-indigo-600 text-white rounded-lg px-4 py-2 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <Send className="h-5 w-5" />
                </button>
              </div>
            </form>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <p className="text-gray-500">Select a chat to start messaging</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ChatPanel;