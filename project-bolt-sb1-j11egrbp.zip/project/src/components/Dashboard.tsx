import React from 'react';
import { BarChart3, MessageSquare, Bell, Users, Calendar, Sun, Moon } from 'lucide-react';
import StatCard from './StatCard';
import TaskChart from './TaskChart';
import ChatPanel from './ChatPanel';
import NotificationsPanel from './NotificationsPanel';
import MeetingsPanel from './MeetingsPanel';

const Dashboard = () => {
  const toggleDarkMode = () => {
    document.documentElement.classList.toggle('dark');
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-dark-surface transition-colors duration-200">
      <nav className="glass-effect border-b border-gray-200 dark:border-dark-border fixed w-full z-30 top-0">
        <div className="px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <BarChart3 className="h-8 w-8 text-indigo-600" />
              <span className="ml-2 text-xl font-semibold bg-gradient-to-r from-indigo-500 to-purple-500 bg-clip-text text-transparent">
                Efficio
              </span>
            </div>
            <div className="flex items-center space-x-4">
              <button 
                onClick={toggleDarkMode}
                className="p-2 text-gray-500 hover:text-gray-600 dark:text-gray-400 dark:hover:text-gray-300"
              >
                <Sun className="h-5 w-5 hidden dark:block" />
                <Moon className="h-5 w-5 block dark:hidden" />
              </button>
              <button className="p-2 text-gray-500 hover:text-gray-600 dark:text-gray-400 dark:hover:text-gray-300">
                <Bell className="h-6 w-6" />
              </button>
              <div className="h-8 w-8 rounded-full bg-gradient-to-r from-indigo-500 to-purple-500"></div>
            </div>
          </div>
        </div>
      </nav>

      <div className="pt-16">
        <div className="max-w-[1920px] mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Stats Row */}
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2 xl:grid-cols-4">
            <StatCard
              title="Pending Tasks"
              value="23"
              icon={<Calendar className="h-6 w-6 text-blue-500" />}
              change="+2.5%"
              type="increase"
            />
            <StatCard
              title="Active Chats"
              value="12"
              icon={<MessageSquare className="h-6 w-6 text-green-500" />}
              change="-5%"
              type="decrease"
            />
            <StatCard
              title="Team Members"
              value="8"
              icon={<Users className="h-6 w-6 text-purple-500" />}
              change="0%"
              type="neutral"
            />
            <StatCard
              title="Completion Rate"
              value="94%"
              icon={<BarChart3 className="h-6 w-6 text-yellow-500" />}
              change="+4%"
              type="increase"
            />
          </div>

          {/* Main Content Grid */}
          <div className="mt-8 grid grid-cols-1 xl:grid-cols-3 gap-6">
            {/* Left Column */}
            <div className="xl:col-span-2 space-y-6">
              <div className="glass-effect card-gradient rounded-lg shadow-lg dark:shadow-indigo-500/10">
                <div className="p-6">
                  <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Task Distribution</h2>
                  <TaskChart />
                </div>
              </div>
              <div className="glass-effect card-gradient rounded-lg shadow-lg dark:shadow-indigo-500/10">
                <div className="p-6">
                  <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Recent Activity</h2>
                  <NotificationsPanel />
                </div>
              </div>
            </div>

            {/* Right Column */}
            <div className="space-y-6">
              <div className="glass-effect card-gradient rounded-lg shadow-lg dark:shadow-indigo-500/10">
                <MeetingsPanel />
              </div>
              <div className="glass-effect card-gradient rounded-lg shadow-lg dark:shadow-indigo-500/10">
                <ChatPanel />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;