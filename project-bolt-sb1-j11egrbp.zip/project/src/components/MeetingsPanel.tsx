import React, { useState } from 'react';
import { Calendar, Clock, Users, Plus, X } from 'lucide-react';

interface Meeting {
  id: number;
  title: string;
  date: string;
  time: string;
  attendees: string[];
  room: string;
}

const initialMeetings: Meeting[] = [
  {
    id: 1,
    title: 'Sprint Planning',
    date: '2025-03-15',
    time: '10:00',
    attendees: ['Sarah K.', 'Mike R.', 'John D.'],
    room: 'Room 101'
  },
  {
    id: 2,
    title: 'Design Review',
    date: '2025-03-15',
    time: '14:00',
    attendees: ['Emma S.', 'Chris P.'],
    room: 'Room 102'
  },
  {
    id: 3,
    title: 'Team Retrospective',
    date: '2025-03-16',
    time: '11:00',
    attendees: ['Sarah K.', 'Mike R.', 'John D.', 'Emma S.', 'Chris P.'],
    room: 'Room 103'
  }
];

const MeetingsPanel = () => {
  const [meetings, setMeetings] = useState<Meeting[]>(initialMeetings);
  const [showNewMeeting, setShowNewMeeting] = useState(false);
  const [newMeeting, setNewMeeting] = useState({
    title: '',
    date: '',
    time: '',
    attendees: '',
    room: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const meeting: Meeting = {
      id: meetings.length + 1,
      title: newMeeting.title,
      date: newMeeting.date,
      time: newMeeting.time,
      attendees: newMeeting.attendees.split(',').map(a => a.trim()),
      room: newMeeting.room
    };
    setMeetings([...meetings, meeting]);
    setShowNewMeeting(false);
    setNewMeeting({ title: '', date: '', time: '', attendees: '', room: '' });
  };

  return (
    <div className="bg-white rounded-lg shadow">
      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-lg font-semibold text-gray-900">Scheduled Meetings</h2>
          <button
            onClick={() => setShowNewMeeting(true)}
            className="flex items-center px-3 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <Plus className="h-4 w-4 mr-2" />
            Schedule Meeting
          </button>
        </div>

        {showNewMeeting && (
          <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 w-full max-w-md">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold">Schedule New Meeting</h3>
                <button onClick={() => setShowNewMeeting(false)} className="text-gray-500 hover:text-gray-700">
                  <X className="h-5 w-5" />
                </button>
              </div>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Title</label>
                  <input
                    type="text"
                    value={newMeeting.title}
                    onChange={(e) => setNewMeeting({ ...newMeeting, title: e.target.value })}
                    className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Date</label>
                  <input
                    type="date"
                    value={newMeeting.date}
                    onChange={(e) => setNewMeeting({ ...newMeeting, date: e.target.value })}
                    className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Time</label>
                  <input
                    type="time"
                    value={newMeeting.time}
                    onChange={(e) => setNewMeeting({ ...newMeeting, time: e.target.value })}
                    className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Attendees (comma-separated)</label>
                  <input
                    type="text"
                    value={newMeeting.attendees}
                    onChange={(e) => setNewMeeting({ ...newMeeting, attendees: e.target.value })}
                    className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="John D., Sarah K."
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Room</label>
                  <input
                    type="text"
                    value={newMeeting.room}
                    onChange={(e) => setNewMeeting({ ...newMeeting, room: e.target.value })}
                    className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    required
                  />
                </div>
                <button
                  type="submit"
                  className="w-full bg-indigo-600 text-white rounded-lg px-4 py-2 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  Schedule Meeting
                </button>
              </form>
            </div>
          </div>
        )}

        <div className="space-y-4">
          {meetings.map((meeting) => (
            <div key={meeting.id} className="border rounded-lg p-4 hover:bg-gray-50">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-medium text-gray-900">{meeting.title}</h3>
                  <div className="mt-2 space-y-2">
                    <div className="flex items-center text-sm text-gray-500">
                      <Calendar className="h-4 w-4 mr-2" />
                      {meeting.date}
                    </div>
                    <div className="flex items-center text-sm text-gray-500">
                      <Clock className="h-4 w-4 mr-2" />
                      {meeting.time}
                    </div>
                    <div className="flex items-center text-sm text-gray-500">
                      <Users className="h-4 w-4 mr-2" />
                      {meeting.attendees.join(', ')}
                    </div>
                  </div>
                </div>
                <span className="text-sm font-medium text-indigo-600 bg-indigo-50 px-2 py-1 rounded">
                  {meeting.room}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MeetingsPanel;