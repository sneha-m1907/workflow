import React from 'react';
import { Bell, Calendar, MessageSquare, AlertCircle } from 'lucide-react';

const notifications = [
  {
    id: 1,
    type: 'mention',
    message: '@sarah mentioned you in UI Design discussion',
    time: '5m ago',
    icon: MessageSquare,
    color: 'text-blue-600',
  },
  {
    id: 2,
    type: 'meeting',
    message: 'Team standup in 30 minutes',
    time: '25m ago',
    icon: Calendar,
    color: 'text-green-600',
  },
  {
    id: 3,
    type: 'alert',
    message: 'Project deadline approaching',
    time: '1h ago',
    icon: AlertCircle,
    color: 'text-red-600',
  },
  {
    id: 4,
    type: 'notification',
    message: 'New project guidelines available',
    time: '2h ago',
    icon: Bell,
    color: 'text-purple-600',
  },
];

const NotificationsPanel = () => {
  return (
    <div className="space-y-4">
      {notifications.map((notification) => (
        <div key={notification.id} className="flex items-start space-x-3">
          <div className={`${notification.color} mt-1`}>
            <notification.icon className="h-5 w-5" />
          </div>
          <div className="flex-1">
            <p className="text-sm text-gray-900">{notification.message}</p>
            <span className="text-xs text-gray-500">{notification.time}</span>
          </div>
        </div>
      ))}
    </div>
  );
};

export default NotificationsPanel;