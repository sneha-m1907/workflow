import React from 'react';
import { ArrowUpIcon, ArrowDownIcon, MinusIcon } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string;
  icon: React.ReactNode;
  change: string;
  type: 'increase' | 'decrease' | 'neutral';
}

const StatCard: React.FC<StatCardProps> = ({ title, value, icon, change, type }) => {
  return (
    <div className="glass-effect card-gradient rounded-lg shadow-lg dark:shadow-indigo-500/10 p-6 transition-all duration-200 hover:scale-[1.02]">
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          {icon}
          <h3 className="ml-3 text-lg font-medium text-gray-900 dark:text-white">{title}</h3>
        </div>
      </div>
      <p className="mt-4 text-2xl font-semibold text-gray-900 dark:text-white">{value}</p>
      <div className="mt-2 flex items-center">
        {type === 'increase' && <ArrowUpIcon className="h-4 w-4 text-green-500" />}
        {type === 'decrease' && <ArrowDownIcon className="h-4 w-4 text-red-500" />}
        {type === 'neutral' && <MinusIcon className="h-4 w-4 text-gray-500 dark:text-gray-400" />}
        <span className={`ml-2 text-sm ${
          type === 'increase' ? 'text-green-500' : 
          type === 'decrease' ? 'text-red-500' : 
          'text-gray-500 dark:text-gray-400'
        }`}>
          {change} from last week
        </span>
      </div>
    </div>
  );
};

export default StatCard;