import React from 'react';

const TaskChart = () => {
  // This is a placeholder for the actual chart implementation
  // You would typically use a library like Chart.js or Recharts here
  return (
    <div className="h-64 flex items-center justify-center bg-gray-50 rounded-lg">
      <div className="space-y-4">
        <div className="flex items-center space-x-4">
          <div className="w-32 h-4 bg-blue-200 rounded"></div>
          <span className="text-sm text-gray-600">High Priority (8)</span>
        </div>
        <div className="flex items-center space-x-4">
          <div className="w-24 h-4 bg-yellow-200 rounded"></div>
          <span className="text-sm text-gray-600">Medium Priority (6)</span>
        </div>
        <div className="flex items-center space-x-4">
          <div className="w-16 h-4 bg-green-200 rounded"></div>
          <span className="text-sm text-gray-600">Low Priority (4)</span>
        </div>
      </div>
    </div>
  );
};

export default TaskChart;